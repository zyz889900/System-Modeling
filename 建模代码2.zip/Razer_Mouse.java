package System;


/**
 * @author yize
 * @version 1.0
 * @created 03-ʮ����-2020 16:15:19
 */
public class Razer_Mouse implements IMouse {

	public Razer_Mouse(){

	}

	public void finalize() throws Throwable {

	}

	public Mouseinfo(){

	}

}