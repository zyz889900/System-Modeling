package System;


/**
 * @author yize
 * @version 1.0
 * @created 03-ʮ����-2020 16:15:19
 */
public class OfficeFactory implements AbstractFactory {

	public OfficeFactory(){

	}

	public void finalize() throws Throwable {

	}

	public IKeyboard createKeyboard(){
		return null;
	}

	public IMouse createMouse(){
		return null;
	}

}