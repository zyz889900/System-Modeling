package System;

public class Client {

	public Client(){

	}

	public void finalize() throws Throwable {

	}

	public void getProduct(){

	}

	public static void main(String[] args) {
		AbstractFactory f;
		IMouse m;
		IKeyboard k;

		f = new GameFactory();
		m = f.createMouse();
		m.Mouseinfo();
		k = f.createKeyboard();
		k.keyboardinfo();

		f = new OfficeFactory();
		m = f.createMouse();
		m.Mouseinfo();
		k = f.createKeyboard();
		k.keyboardinfo();
	}
}