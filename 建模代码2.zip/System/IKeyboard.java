package System;

interface IKeyboard {

	public void keyboardinfo();

}