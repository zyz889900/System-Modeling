package System;

interface IMouse {

	public void Mouseinfo();

}