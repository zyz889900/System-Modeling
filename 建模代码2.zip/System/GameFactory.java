package System;

class GameFactory implements AbstractFactory {

	public GameFactory(){

	}

	public void finalize() throws Throwable {

	}

	public IKeyboard createKeyboard(){
		return new Logitech_Keyboard();
	}

	public IMouse createMouse(){
		return new Razer_Mouse();
	}

}