package System;

class Razer_Mouse implements IMouse {

	public Razer_Mouse(){

	}

	public void finalize() throws Throwable {

	}

	public void Mouseinfo(){
		System.out.println("我是雷蛇鼠标，适合打游戏!");
	}

}