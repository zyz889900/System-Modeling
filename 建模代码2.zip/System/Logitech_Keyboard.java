package System;

class Logitech_Keyboard implements IKeyboard {

	public Logitech_Keyboard(){

	}

	public void finalize() throws Throwable {

	}

	public void keyboardinfo(){
		System.out.println("我是罗技键盘，适合打游戏！");
	}

}