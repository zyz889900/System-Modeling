package System;

interface AbstractFactory {

	public IKeyboard createKeyboard();

	public IMouse createMouse();

}