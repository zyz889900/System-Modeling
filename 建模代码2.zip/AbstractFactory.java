package System;


/**
 * @author yize
 * @version 1.0
 * @created 03-ʮ����-2020 16:15:18
 */
public interface AbstractFactory {

	public IKeyboard createKeyboard();

	public IMouse createMouse();

}