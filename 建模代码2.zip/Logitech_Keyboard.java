package System;


/**
 * @author yize
 * @version 1.0
 * @created 03-ʮ����-2020 16:15:19
 */
public class Logitech_Keyboard implements IKeyboard {

	public Logitech_Keyboard(){

	}

	public void finalize() throws Throwable {

	}

	public keyboardinfo(){

	}

}