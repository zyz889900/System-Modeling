package System;


/**
 * @version 1.0
 * @created 24-ʮһ��-2020 17:40:01
 */
public class Client {

	public Client(){

	}

	public void finalize() throws Throwable {

	}

	public void getProduct(){

	}

}