package System;


/**
 * @author yize
 * @version 1.0
 * @created 24-ʮһ��-2020 17:40:05
 */
public interface IKeyboard {

	public keyboardinfo();

}