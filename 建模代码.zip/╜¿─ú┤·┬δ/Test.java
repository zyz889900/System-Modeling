package System;

public class Test{
    public static void getProduct(){
	IAbsFactory f;
	IMouse m;
	IKeyboard k;
	//��Ҫ��ʾ�޼���װ
	f=new LogitechFactory();
	m=f.createMouse();
	m.MouseInfo();
	k=f.createKeyboard();
	k.keyboardInfo();
	//��Ҫ��ʾ������װ
	f=new RazerFactory();
	m=f.createMouse();
	m.MouseInfo();
	k=f.createKeyboard();
	k.keyboardInfo();
	
    }
    public static void main(String[] args){
	getProduct();
    }
}