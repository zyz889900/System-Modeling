package System;


/**
 * @author yize
 * @version 1.0
 * @created 24-ʮһ��-2020 17:40:07
 */
public class RazerFactory implements IAbaFactory {

	public RazerFactory(){

	}

	public void finalize() throws Throwable {

	}

	public IKeyboard createKeyboard(){
		return New Razer_Mouse;
	}

	public IMouse createMouse(){
		return New Razer_Mouse();
	}

}