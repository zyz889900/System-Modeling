package System;


/**
 * @version 1.0
 * @created 24-ʮһ��-2020 17:40:05
 */
public interface IMouse {

	public Mouseinfo();

}