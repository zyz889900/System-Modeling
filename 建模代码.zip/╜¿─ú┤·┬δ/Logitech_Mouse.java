package System;


/**
 * @author yize
 * @version 1.0
 * @created 24-ʮһ��-2020 17:40:10
 */
public class Logitech_Mouse implements IMouse {
	public IMouse(){

	}
	public Logitech_Mouse(){
		
	}

	public void finalize() throws Throwable {

	}

	public Mouseinfo(){
		System.out.println("�����޼���꣬�ʺϰ칫��");
	}

}