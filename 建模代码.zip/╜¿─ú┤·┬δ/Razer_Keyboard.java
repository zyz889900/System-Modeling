package System;


/**
 * @author yize
 * @version 1.0
 * @created 24-ʮһ��-2020 17:40:09
 */
public class Razer_Keyboard implements IKeyboard {
	public IKeyboard(){

	}	

	public Razer_Keyboard(){
		
	}

	public void finalize() throws Throwable {

	}

	public keyboardinfo(){
		System.out.println("�������߼��̣��ʺϰ칫��");
	}

}