package System;


/**
 * @author yize
 * @version 1.0
 * @created 24-ʮһ��-2020 17:40:07
 */
public class LogitechFactory implements IAbaFactory {

	public LogitechFactory(){

	}

	public void finalize() throws Throwable {

	}

	public IKeyboard createKeyboard(){
		return New Logitech_Keyboard;
	}

	public IMouse createMouse(){
		return New Logitech_Mouse;
	}

}