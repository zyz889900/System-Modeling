package System;


/**
 * @author yize
 * @version 1.0
 * @created 24-ʮһ��-2020 18:17:57
 */
public interface IAbsFactory {

	public IKeyboard createKeyboard();

	public IMouse createMouse();

}