package System;

class Razer_Mouse implements IMouse {
	public void IMouse() {

	}

	public Razer_Mouse() {

	}

	public void finalize() throws Throwable {

	}

	public void Mouseinfo() {
		System.out.println("我是罗技鼠标，适合办公！");
	}
}