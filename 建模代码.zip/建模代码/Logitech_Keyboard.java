package System;

class Logitech_Keyboard implements IKeyboard {
	public void IKeyboard() {

	}

	public Logitech_Keyboard() {

	}

	public void finalize() throws Throwable {

	}

	public void keyboardinfo() {
		System.out.println("我是雷蛇键盘，适合打游戏！");
	}
}