package System;

class Razer_Keyboard implements IKeyboard {
	public void IKeyboard(){

	}	

	public Razer_Keyboard(){
		
	}

	public void finalize() throws Throwable {

	}

	public void keyboardinfo(){
		System.out.println("我是雷蛇键盘，适合办公！");
	}

}
