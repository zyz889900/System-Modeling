package System;

public interface IKeyboard {

	public void keyboardinfo();

}
