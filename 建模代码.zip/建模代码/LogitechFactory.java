package System;

class LogitechFactory implements IAbsFactory {

	public LogitechFactory(){

	}

	public void finalize() throws Throwable {

	}

	public IKeyboard createKeyboard(){
		return new Logitech_Keyboard();
	}

	public IMouse createMouse(){
		return new Logitech_Mouse();
	}

}
