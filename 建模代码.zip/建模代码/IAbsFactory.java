package System;


public interface IAbsFactory {

	public IKeyboard createKeyboard();

	public IMouse createMouse();

}
