package System;

class RazerFactory implements IAbsFactory {

	public RazerFactory(){

	}

	public void finalize() throws Throwable {

	}

	public IKeyboard createKeyboard(){
		return new Razer_Keyboard();
	}

	public IMouse createMouse(){
		return new Razer_Mouse();
	}

}
