package System;

class Logitech_Mouse implements IMouse {
	public void IMouse() {

	}

	public Logitech_Mouse() {

	}

	public void finalize() throws Throwable {

	}

	public void Mouseinfo() {
		System.out.println("我是雷蛇鼠标，适合打游戏！");
	}
}