package System;

class Client {

	public Client() {

	}

	public void finalize() throws Throwable {

	}

	public void getProduct() {

	}

	public static void main(String[] args) {
		IAbsFactory f;
		IMouse m;
		IKeyboard k;

		f = new LogitechFactory();
		m = f.createMouse();
		m.Mouseinfo();
		k = f.createKeyboard();
		k.keyboardinfo();

		f = new RazerFactory();
		m = f.createMouse();
		m.Mouseinfo();
		k = f.createKeyboard();
		k.keyboardinfo();
	}
}