package System;

public interface IMouse {

	public void Mouseinfo();

}